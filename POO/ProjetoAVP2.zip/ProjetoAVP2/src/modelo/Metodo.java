package modelo;

import java.util.ArrayList;

public class Metodo {
	ArrayList<Avaliacao> listaAvaliacao = new ArrayList<Avaliacao>();

	public ArrayList<Avaliacao> getListaAvaliacao() {
		return listaAvaliacao;
	}
	
	

}
